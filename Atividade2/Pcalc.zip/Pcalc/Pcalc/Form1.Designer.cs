﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btmsair = new System.Windows.Forms.Button();
            this.Btmlimpar = new System.Windows.Forms.Button();
            this.Btmdivisao = new System.Windows.Forms.Button();
            this.Btmmultiplicacao = new System.Windows.Forms.Button();
            this.BtmSubtracao = new System.Windows.Forms.Button();
            this.Btmsoma = new System.Windows.Forms.Button();
            this.Txtnumero1 = new System.Windows.Forms.TextBox();
            this.Txtresultado = new System.Windows.Forms.TextBox();
            this.Txtnumero2 = new System.Windows.Forms.TextBox();
            this.Lblresultado = new System.Windows.Forms.Label();
            this.Lblnumero2 = new System.Windows.Forms.Label();
            this.Lblnumero1 = new System.Windows.Forms.Label();
            this.Btmpotencia = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Btmsair
            // 
            this.Btmsair.Location = new System.Drawing.Point(253, 308);
            this.Btmsair.Name = "Btmsair";
            this.Btmsair.Size = new System.Drawing.Size(135, 61);
            this.Btmsair.TabIndex = 0;
            this.Btmsair.Text = "Sair";
            this.Btmsair.UseVisualStyleBackColor = true;
            this.Btmsair.Click += new System.EventHandler(this.Btmsair_Click);
            // 
            // Btmlimpar
            // 
            this.Btmlimpar.Location = new System.Drawing.Point(73, 308);
            this.Btmlimpar.Name = "Btmlimpar";
            this.Btmlimpar.Size = new System.Drawing.Size(135, 61);
            this.Btmlimpar.TabIndex = 1;
            this.Btmlimpar.Text = "Limpar";
            this.Btmlimpar.UseVisualStyleBackColor = true;
            this.Btmlimpar.Click += new System.EventHandler(this.Btmlimpar_Click);
            // 
            // Btmdivisao
            // 
            this.Btmdivisao.Location = new System.Drawing.Point(553, 79);
            this.Btmdivisao.Name = "Btmdivisao";
            this.Btmdivisao.Size = new System.Drawing.Size(109, 67);
            this.Btmdivisao.TabIndex = 2;
            this.Btmdivisao.Text = "/";
            this.Btmdivisao.UseVisualStyleBackColor = true;
            this.Btmdivisao.Click += new System.EventHandler(this.Btmdivisao_Click);
            // 
            // Btmmultiplicacao
            // 
            this.Btmmultiplicacao.Location = new System.Drawing.Point(417, 252);
            this.Btmmultiplicacao.Name = "Btmmultiplicacao";
            this.Btmmultiplicacao.Size = new System.Drawing.Size(109, 67);
            this.Btmmultiplicacao.TabIndex = 3;
            this.Btmmultiplicacao.Text = "*";
            this.Btmmultiplicacao.UseVisualStyleBackColor = true;
            this.Btmmultiplicacao.Click += new System.EventHandler(this.Btmmultiplicacao_Click);
            // 
            // BtmSubtracao
            // 
            this.BtmSubtracao.Location = new System.Drawing.Point(417, 165);
            this.BtmSubtracao.Name = "BtmSubtracao";
            this.BtmSubtracao.Size = new System.Drawing.Size(109, 67);
            this.BtmSubtracao.TabIndex = 4;
            this.BtmSubtracao.Text = "-";
            this.BtmSubtracao.UseVisualStyleBackColor = true;
            this.BtmSubtracao.Click += new System.EventHandler(this.BtmSubtracao_Click);
            // 
            // Btmsoma
            // 
            this.Btmsoma.Location = new System.Drawing.Point(417, 79);
            this.Btmsoma.Name = "Btmsoma";
            this.Btmsoma.Size = new System.Drawing.Size(109, 67);
            this.Btmsoma.TabIndex = 5;
            this.Btmsoma.Text = "+";
            this.Btmsoma.UseVisualStyleBackColor = true;
            this.Btmsoma.Click += new System.EventHandler(this.Btmsoma_Click);
            // 
            // Txtnumero1
            // 
            this.Txtnumero1.Location = new System.Drawing.Point(120, 79);
            this.Txtnumero1.Name = "Txtnumero1";
            this.Txtnumero1.Size = new System.Drawing.Size(266, 26);
            this.Txtnumero1.TabIndex = 6;
            this.Txtnumero1.Validated += new System.EventHandler(this.Txtnumero1_Validated);
            // 
            // Txtresultado
            // 
            this.Txtresultado.Enabled = false;
            this.Txtresultado.Location = new System.Drawing.Point(120, 227);
            this.Txtresultado.Name = "Txtresultado";
            this.Txtresultado.Size = new System.Drawing.Size(266, 26);
            this.Txtresultado.TabIndex = 7;
            // 
            // Txtnumero2
            // 
            this.Txtnumero2.Location = new System.Drawing.Point(120, 135);
            this.Txtnumero2.Name = "Txtnumero2";
            this.Txtnumero2.Size = new System.Drawing.Size(266, 26);
            this.Txtnumero2.TabIndex = 8;
            this.Txtnumero2.Validated += new System.EventHandler(this.Txtnumero2_Validated);
            // 
            // Lblresultado
            // 
            this.Lblresultado.AutoSize = true;
            this.Lblresultado.Location = new System.Drawing.Point(38, 230);
            this.Lblresultado.Name = "Lblresultado";
            this.Lblresultado.Size = new System.Drawing.Size(82, 20);
            this.Lblresultado.TabIndex = 9;
            this.Lblresultado.Text = "Resultado";
            // 
            // Lblnumero2
            // 
            this.Lblnumero2.AutoSize = true;
            this.Lblnumero2.Location = new System.Drawing.Point(38, 141);
            this.Lblnumero2.Name = "Lblnumero2";
            this.Lblnumero2.Size = new System.Drawing.Size(78, 20);
            this.Lblnumero2.TabIndex = 10;
            this.Lblnumero2.Text = "Numero 2";
            // 
            // Lblnumero1
            // 
            this.Lblnumero1.AutoSize = true;
            this.Lblnumero1.Location = new System.Drawing.Point(38, 82);
            this.Lblnumero1.Name = "Lblnumero1";
            this.Lblnumero1.Size = new System.Drawing.Size(78, 20);
            this.Lblnumero1.TabIndex = 11;
            this.Lblnumero1.Text = "Numero 1";
            // 
            // Btmpotencia
            // 
            this.Btmpotencia.Location = new System.Drawing.Point(553, 165);
            this.Btmpotencia.Name = "Btmpotencia";
            this.Btmpotencia.Size = new System.Drawing.Size(109, 67);
            this.Btmpotencia.TabIndex = 12;
            this.Btmpotencia.Text = "x^y";
            this.Btmpotencia.UseVisualStyleBackColor = true;
            this.Btmpotencia.Click += new System.EventHandler(this.Btmpotencia_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 681);
            this.Controls.Add(this.Btmpotencia);
            this.Controls.Add(this.Lblnumero1);
            this.Controls.Add(this.Lblnumero2);
            this.Controls.Add(this.Lblresultado);
            this.Controls.Add(this.Txtnumero2);
            this.Controls.Add(this.Txtresultado);
            this.Controls.Add(this.Txtnumero1);
            this.Controls.Add(this.Btmsoma);
            this.Controls.Add(this.BtmSubtracao);
            this.Controls.Add(this.Btmmultiplicacao);
            this.Controls.Add(this.Btmdivisao);
            this.Controls.Add(this.Btmlimpar);
            this.Controls.Add(this.Btmsair);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btmsair;
        private System.Windows.Forms.Button Btmlimpar;
        private System.Windows.Forms.Button Btmdivisao;
        private System.Windows.Forms.Button Btmmultiplicacao;
        private System.Windows.Forms.Button BtmSubtracao;
        private System.Windows.Forms.Button Btmsoma;
        private System.Windows.Forms.TextBox Txtnumero1;
        private System.Windows.Forms.TextBox Txtresultado;
        private System.Windows.Forms.TextBox Txtnumero2;
        private System.Windows.Forms.Label Lblresultado;
        private System.Windows.Forms.Label Lblnumero2;
        private System.Windows.Forms.Label Lblnumero1;
        private System.Windows.Forms.Button Btmpotencia;
    }
}

