﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double n1, n2, resultado;
        public Form1()
        {
            
            InitializeComponent();
        }
        private void Btmlimpar_Click(object sender, EventArgs e)
        {
            Txtnumero1.Clear();
            Txtnumero2.Clear();
            Txtresultado.Clear();
        }

        private void Btmsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                Close();
        }

        private void Btmsoma_Click(object sender, EventArgs e)
        {
            resultado = n1 + n2;
            Txtresultado.Text = resultado.ToString();
        }

        private void BtmSubtracao_Click(object sender, EventArgs e)
        {
            resultado = n1 - n2;
            Txtresultado.Text = resultado.ToString();
        }

        private void Btmmultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = n1 * n2;
            Txtresultado.Text = resultado.ToString();
        }

        private void Btmdivisao_Click(object sender, EventArgs e)
        {
            if (n2 == 0)
            {
                MessageBox.Show("Não pode divisão com 0", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Txtnumero2.Clear();
                Txtnumero2.Focus();
            }
            else
            {
                resultado = n1 / n2;
                Txtresultado.Text = resultado.ToString();
            }
        }

        private void Btmpotencia_Click(object sender, EventArgs e)
        {
            resultado = Math.Pow(n1, n2);
            Txtresultado.Text = resultado.ToString();
        }

        private void Txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(Txtnumero1.Text, out n1))
            {
                MessageBox.Show("Seu número está inválido");
                 Txtnumero1.Focus();
            }
        }

        private void Txtnumero2_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(Txtnumero2.Text, out n2))
            {
                MessageBox.Show("Número invalido!");
                    Txtnumero2.Focus();
            }
            
        }
    }
}
